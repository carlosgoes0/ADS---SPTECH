# ENVIO SMS PYTHON VIA TeleSign
- Leandro - 1802049
- Lucas - 1800671
- Fernanda -1800229
- Leonardo - 1701888
- Bruno - 1800547
- Fabio - 1800525
